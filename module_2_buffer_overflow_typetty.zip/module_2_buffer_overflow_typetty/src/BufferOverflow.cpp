// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  // Collect the user's input
  const std::string account_number = "CharlieBrown42";
  char user_input[20];
  std::cout << "Enter a value: ";
  std::cin >> std::setw(sizeof(user_input)) >> user_input; // Ensure that the input doesn't exceed 20 chars

  // if the user puts too many characters in the input, the last space of the input will not be a new line. Tell the user of the error.
  if (std::cin.peek() != '\n') {
	  std::cout << "\nERROR --> The maximum length value you can enter is 19 characters. Too many characters were provided so we truncated your response.\n" << std::endl;
  }

  // Output the results
  std::cout << "You entered: " << user_input << std::endl;
  std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
