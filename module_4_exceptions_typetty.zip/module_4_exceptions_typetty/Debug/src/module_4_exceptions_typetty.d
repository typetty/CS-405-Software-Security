src/module_4_exceptions_typetty.o: ../src/module_4_exceptions_typetty.cpp
