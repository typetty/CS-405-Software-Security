//============================================================================
// Name        : module_4_exceptions_typetty.cpp
// Author      : Ty Petty
// Version     : 1.0
// Copyright   : Your copyright notice
// Description : Module 4 CPP Code for Exceptions
//============================================================================

// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

// Created my own custom exception
class MyCustomException : public std::exception {
private:
  std::string message;

public:
  explicit MyCustomException(const std::string& msg) : message(msg) {}

  const char* what() const noexcept override {
    return message.c_str();
  }

};

bool do_even_more_custom_application_logic()
{
  // I chose runtime error for the random exception to throw
  throw std::runtime_error("This is a runtime error that is being thrown.");

  std::cout << "Running Even More Custom Application Logic." << std::endl;

  return true;
}

void do_custom_application_logic()
{
  std::cout << "Running Custom Application Logic." << std::endl;

  // Added a try/catch statement for the do_eve_more_customer_application_logic call.
  try {
	if(do_even_more_custom_application_logic()) {
	   std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
	}
  } catch (const std::exception& ex) { // Make it display what exception is caught if one is caught
	  std::cout << "The following exception has been caught --> " << ex.what() << std::endl;
  }

  // A custom exception is thrown here
  throw MyCustomException("This is my custom exception!");

  std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
  // If the denominator is 0, throw an exception
  if (den == 0) {
	  throw std::invalid_argument("You cannot divide by zero.");
  }

  return (num / den);
}

void do_division() noexcept
{
  float numerator = 10.0f;
  float denominator = 0;

  try {
	// Try to divide the numerator by the denominator
	auto result = divide(numerator, denominator);
	std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
  } catch (const std::exception& ex) {
	// Display the error that occurred while trying to divide
	std::cout << "Exception while doing division --> " << ex.what() << std::endl;
  }
}

int main()
{
  std::cout << "Exceptions Tests!" << std::endl;

  // Capture the custom exception, standard exception, and unknown exceptions in a try/catch statement
  try {
	do_division();
	do_custom_application_logic();
  } catch (const MyCustomException& ex) {
	  std::cout << "A Custom Exception was detected --> " << ex.what() << std::endl;
  } catch (const std::exception& ex) {
	  std::cout << "A Standard Exception was detected --> " << ex.what() << std::endl;
  } catch (...) {
	  std::cout << "An unknown exception was detected." << std::endl;
  }

  return 0;

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
