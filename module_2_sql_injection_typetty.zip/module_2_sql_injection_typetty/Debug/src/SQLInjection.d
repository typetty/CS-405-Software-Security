src/SQLInjection.o: ../src/SQLInjection.cpp ../src/sqlite3.h
../src/sqlite3.h:
