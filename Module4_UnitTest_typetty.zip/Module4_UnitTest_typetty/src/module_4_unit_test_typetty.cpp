//============================================================================
// Name        : module_4_unit_test_typetty.cpp
// Author      : Ty Petty
// Version     : 1.0
// Description : CPP file for unit testing in Module 4
//============================================================================

// Uncomment the next line to use precompiled headers
//#include "pch.h"
// uncomment the next line if you do not use precompiled headers
#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
  ~Environment() override {}

  // Override this to define how to set up the environment.
  void SetUp() override
  {
    //  initialize random seed
    srand(time(nullptr));
  }

  // Override this to define how to tear down the environment.
  void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
  // create a smart point to hold our collection
  std::unique_ptr<std::vector<int>> collection;

  void SetUp() override
  { // create a new collection to be used in the test
    collection.reset( new std::vector<int>);
  }

  void TearDown() override
  { //  erase all elements in the collection, if any remain
    collection->clear();
    // free the pointer
    collection.reset(nullptr);
  }

  // helper function to add random values from 0 to 99 count times to the collection
  void add_entries(int count)
  {
    assert(count > 0);
    for (auto i = 0; i < count; ++i)
      collection->push_back(rand() % 100);
  }
};




//=========================================================//
//                      UNIT TESTS                         //
//=========================================================//

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull) {
  // is the collection created
  ASSERT_TRUE(collection);

  // if empty, the size must be 0
  ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate) {
  // is the collection empty?
  ASSERT_TRUE(collection->empty());

  // if empty, the size must be 0
  ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
TEST_F(CollectionTest, AlwaysFail) {
  FAIL();
}

// Test to verify adding a single value to an empty collection - Edited by TP
TEST_F(CollectionTest, CanAddToEmptyVector) {
  // is the collection empty?
  ASSERT_TRUE(collection->empty());
  // if empty, the size must be 0
  ASSERT_EQ(collection->size(), 0);

  // Add an entry to an empty collection
  add_entries(1);

  // is the collection still empty? It should not be
  EXPECT_FALSE(collection->empty());
  // if not empty, what must the size be?
  EXPECT_EQ(collection->size(), 1);
}

// Test to verify adding five values to collection - Edited by TP
TEST_F(CollectionTest, CanAddFiveValuesToVector) {
  // First let's verify that the collection is empty
  ASSERT_TRUE(collection->empty());

  // Try to add 5 entries to the collection
  add_entries(5);

  // Now confirm the size of the collection is 5
  EXPECT_EQ(collection->size(), 5);
}

// Test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries - Edited by TP
TEST_F(CollectionTest, MaxSizeIsGreaterThanOrEqualToSize) {
  // First confirm that the collection is empty to start
  ASSERT_TRUE(collection->empty());
  // Then check that the max size is greater than or equal to the current size: 0
  EXPECT_GE(collection->max_size(), collection->size());

  // Now make the collection size equal 1
  add_entries(1);
  // Then check that the max size is greater than or equal to the current size: 1
  EXPECT_GE(collection->max_size(), collection->size());

  // Now make the collection size equal 5
  add_entries(4);
  // Then check that the max size is greater than or equal to the current size: 5
  EXPECT_GE(collection->max_size(), collection->size());

  // Now make the collection size equal 10
  add_entries(5);
  // Then check that the max size is greater than or equal to the current size: 10
  EXPECT_GE(collection->max_size(), collection->size());
}

// Test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries - Edited by TP
TEST_F(CollectionTest, CapacityIsGreaterThanOrEqualToSize) {
  // First confirm that the collection is empty to start
  ASSERT_TRUE(collection->empty());
  // Then check that the capacity is greater than or equal to the current size: 0
  EXPECT_GE(collection->capacity(), collection->size());

  // Now make the collection size equal 1
  add_entries(1);
  // Then check that the capacity is greater than or equal to the current size: 1
  EXPECT_GE(collection->capacity(), collection->size());

  // Now make the collection size equal 5
  add_entries(4);
  // Then check that the capacity is greater than or equal to the current size: 5
  EXPECT_GE(collection->capacity(), collection->size());

  // Now make the collection size equal 10
  add_entries(5);
  // Then check that the capacity is greater than or equal to the current size: 10
  EXPECT_GE(collection->capacity(), collection->size());
}

// Test to verify resizing increases the collection - Edited by TP
TEST_F(CollectionTest, ResizingIncreasesCollectionSize) {
  // First, let's confirm that the collection is empty
  ASSERT_TRUE(collection->empty());

  // Now add 5 entries
  add_entries(5);

  // Now resize the collection to 10 and check that the size matches
  collection->resize(10);
  EXPECT_EQ(collection->size(), 10);
}

// Test to verify resizing decreases the collection - Edited by TP
TEST_F(CollectionTest, ResizingDecreasesCollectionSize) {
  // First, let's confirm that the collection is empty
  ASSERT_TRUE(collection->empty());

  // Now add 5 entries
  add_entries(5);

  // Now resize the collection to 2 and check that the size matches
  collection->resize(2);
  EXPECT_EQ(collection->size(), 2);
}

// Test to verify resizing decreases the collection to zero - Edited by TP
TEST_F(CollectionTest, ResizingCollectionToZero) {
  // First, let's confirm that the collection is empty
  ASSERT_TRUE(collection->empty());

  // Now add 5 entries
  add_entries(5);

  // Now resize the collection to 0 and check that the size matches
  collection->resize(0);
  EXPECT_EQ(collection->size(), 0);
}

// Test to verify clear erases the collection - Edited by TP
TEST_F(CollectionTest, ClearErasesCollection) {
  // First, let's confirm that the collection is empty
  ASSERT_TRUE(collection->empty());

  // Now add 5 entries and verify that it is not empty
  add_entries(5);
  EXPECT_FALSE(collection->empty());

  // Now clear the collection and check that the size matches as well as being empty
  collection->clear();
  EXPECT_EQ(collection->size(), 0);
  EXPECT_TRUE(collection->empty());
}

// Test to verify erase(begin,end) erases the collection - Edited by TP
TEST_F(CollectionTest, EraseBeginToEndErasesCollection) {
  //First, let's confirm that the collection is empty
  ASSERT_TRUE(collection->empty());

  // Now add 5 entries and verify that the collection is not empty
  add_entries(5);
  EXPECT_FALSE(collection->empty());

  // Erase the collection and confirm that it is empty
  collection->erase(collection->begin(), collection->end());
  EXPECT_TRUE(collection->empty());
}

// Test to verify reserve increases the capacity but not the size of the collection - Edited by TP
TEST_F(CollectionTest, ReserveIncreasesCapacityNotSize) {
  // First, let's confirm that the collection is empty
  ASSERT_TRUE(collection->empty());

  // Now add a few entries and then store the size and capacity for later analysis
  add_entries(5);
  size_t last_size = collection->size();
  size_t last_capacity = collection->capacity();

  // Now call reserve
  collection->reserve(last_capacity + 20);

  // Verify that the capacity increased but the size stayed the same
  EXPECT_GT(collection->capacity(), last_capacity);
  EXPECT_EQ(collection->size(), last_size);
}

// Test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test - Edited by TP
TEST_F(CollectionTest, OutOfRangeWhenCallingAtWithBadIndex) {
  // First, let's confirm that the collection is empty
  ASSERT_TRUE(collection->empty());

  // Add some more entries, then call at with an out of bound index to confirm out of range error
  add_entries(5);
  EXPECT_THROW(collection->at(10), std::out_of_range);
}

// Create 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative - Edited by TP

// Test to verify that std::ilength_error exception is thrown if given a negative number to resize (NEGATIVE TEST)
TEST_F(CollectionTest, LengthErrorWithNegativeSize) {
  // First, let's confirm that the collection is empty
  ASSERT_TRUE(collection->empty());

  // Try to resize the collection to a negative number and confirm that it throws and length error exception
  EXPECT_THROW(collection->resize(-5), std::length_error);
}

// Test to verify that you can insert and assign a collection item
TEST_F(CollectionTest, AssignValueToCollectionItem) {
  //  First, let's confirm that the collection is empty
  ASSERT_TRUE(collection->empty());

  // Add an entry
  add_entries(1);

  // Assign a value to the entry
  (*collection)[1] = 50;

  // Verify the value was assigned properly
  EXPECT_EQ((*collection)[1], 50);

}



// We have to define a main for the google test to compile properly
int main(int argc, char **argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
