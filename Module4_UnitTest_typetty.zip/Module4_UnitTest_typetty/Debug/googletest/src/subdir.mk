################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CC_SRCS += \
../googletest/src/gtest-all.cc 

CC_DEPS += \
./googletest/src/gtest-all.d 

OBJS += \
./googletest/src/gtest-all.o 


# Each subdirectory must supply rules for building sources it contributes
googletest/src/%.o: ../googletest/src/%.cc googletest/src/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: GCC C++ Compiler'
	g++ -std=c++17 -I"/Users/typetty/eclipse-workspace/Module4_UnitTest_typetty/googletest/include" -I"/Users/typetty/eclipse-workspace/Module4_UnitTest_typetty/googletest" -O0 -g3 -Wall -c -fmessage-length=0 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-googletest-2f-src

clean-googletest-2f-src:
	-$(RM) ./googletest/src/gtest-all.d ./googletest/src/gtest-all.o

.PHONY: clean-googletest-2f-src

