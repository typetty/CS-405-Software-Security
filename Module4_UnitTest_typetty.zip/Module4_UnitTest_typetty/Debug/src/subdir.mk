################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../src/module_4_unit_test_typetty.cpp 

CPP_DEPS += \
./src/module_4_unit_test_typetty.d 

OBJS += \
./src/module_4_unit_test_typetty.o 


# Each subdirectory must supply rules for building sources it contributes
src/%.o: ../src/%.cpp src/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: GCC C++ Compiler'
	g++ -std=c++17 -I"/Users/typetty/eclipse-workspace/Module4_UnitTest_typetty/googletest/include" -I"/Users/typetty/eclipse-workspace/Module4_UnitTest_typetty/googletest" -O0 -g3 -Wall -c -fmessage-length=0 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-src

clean-src:
	-$(RM) ./src/module_4_unit_test_typetty.d ./src/module_4_unit_test_typetty.o

.PHONY: clean-src

